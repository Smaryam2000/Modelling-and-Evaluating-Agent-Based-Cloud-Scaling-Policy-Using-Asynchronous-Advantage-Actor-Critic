/**
 * A set of benchmarks to assess performance of implemented
 * <a href="http://www.wikiwand.com/en/Heuristic">Heuristics</a> that solves a given
 * optimization problem.
 *
 * @author Manoel Campos da Silva Filho
 */
package org.cloudsimplus.benchmarks;
