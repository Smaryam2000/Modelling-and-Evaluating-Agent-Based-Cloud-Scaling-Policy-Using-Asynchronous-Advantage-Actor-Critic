#### What's this Pull Request does, clear and precisely?

#### Where should the reviewer start?

#### Are there some simulation examples to show the performed changes working?

#### What are the relevant issue ticket numbers?

#### The issues or features included were discussed elsewhere outside github? If yes, please provide the links.

#### Any additional information you want to provide?
