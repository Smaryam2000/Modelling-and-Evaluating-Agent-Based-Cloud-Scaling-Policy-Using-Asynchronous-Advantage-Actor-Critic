/**
 * Provides helper classes to create <a href="https://en.wikipedia.org/wiki/Mock_object">Mock Objects</a>.
 *
 * @author Manoel Campos da Silva Filho
 */
package org.cloudbus.cloudsim.mocks;
