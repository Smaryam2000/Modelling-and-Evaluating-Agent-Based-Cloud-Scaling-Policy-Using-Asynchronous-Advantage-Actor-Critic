# AWS EC2 Instance Templates

This directory provider json templates that can be used
to create VMs with the configurations from AWS EC2 Instances.
The files here were created based on information
available at [AWS website](https://aws.amazon.com/ec2/pricing/on-demand/) 
for "US East (Ohio)" Region.

If you want updated configurations, you need to check the provided link
and change the json files here.