/**
 * Provides network-enabled {@link org.cloudbus.cloudsim.hosts.Host} implementations.
 * For more general information, see the package {@link org.cloudbus.cloudsim.hosts} at the upper level.
 *
 * @author Manoel Campos da Silva Filho
 */
package org.cloudbus.cloudsim.hosts.network;
