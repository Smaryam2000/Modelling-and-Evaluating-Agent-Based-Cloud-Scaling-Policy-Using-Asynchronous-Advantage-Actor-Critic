/**
 * Provides {@link org.cloudbus.cloudsim.allocationpolicies.VmAllocationPolicy} implementations
 * that enables VM migration.
 * For more general information, see the package {@link org.cloudbus.cloudsim.allocationpolicies} at the upper level.
 *
 * @author Manoel Campos da Silva Filho
 */
package org.cloudbus.cloudsim.allocationpolicies.migration;
