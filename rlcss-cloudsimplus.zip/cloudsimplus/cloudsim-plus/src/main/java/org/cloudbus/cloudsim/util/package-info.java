/**
 * Provides general purpose, helper classes used internally by CloudSim Plus.
 */
package org.cloudbus.cloudsim.util;
