/**
 * Provides classes to inject random faults during simulation runtime.
 *
 * @author raysaoliveira
 * @see org.cloudsimplus.faultinjection.HostFaultInjection
 */
package org.cloudsimplus.faultinjection;
