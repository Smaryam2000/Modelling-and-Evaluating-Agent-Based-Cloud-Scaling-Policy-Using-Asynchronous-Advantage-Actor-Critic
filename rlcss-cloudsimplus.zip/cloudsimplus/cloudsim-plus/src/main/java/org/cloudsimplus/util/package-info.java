/**
 * Provides general-purpose, utility classes.
 *
 * @author Manoel Campos da Silva Filho
 */
package org.cloudsimplus.util;
